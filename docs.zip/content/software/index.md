# Contents

Click on a link in the list below to go to that page:

1. [Black pills](../../software/black-pills.html)
1. [Getting VoWiFi working on Xiaomi.eu](../../software/getting-vowifi-working-on-xiaomi-eu.html)
1. [Monero GUI syncing stuck with Ledger](../../software/monero-gui-syncing-stuck-with-ledger.html)
1. [Test and format SD cards](../../software/test-and-format-sd-cards.html)
